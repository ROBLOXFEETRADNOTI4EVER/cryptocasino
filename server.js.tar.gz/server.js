import express from "express";
import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import cors from "cors";
import dotenv from "dotenv";
import multer from "multer";
import axios from "axios";
import path from "path";
import fs from "fs";
import SibApiV3Sdk from '@sendinblue/client';
import { type } from "os";

dotenv.config();

const app = express();
const port = 4002;

app.use(cors());
app.use(express.json());




// makeing sure uplods directory exist
if (!fs.existsSync("uploads")) {
  fs.mkdirSync("uploads");
}

const mongoURI = process.env.MONGO_URI || "mongodb://localhost:27017/myDatabase"; 

mongoose.connect(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log("Connected to MongoDB"))
  .catch((error) => console.error("Error connecting to MongoDB:", error));

  const UserSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    rank: { type: String, default: "User" },
    bitcoinnumb: { type: Number, default: 0 },
    bitcoinAdress: { type: String, unique: true, default: "No adress generated" },
    etheriumnumb: { type: Number, default: 0 },
    etheriumAdress: { type: String, unique: true, default: "No adress generated" },
    litecoinNumb: { type: Number, default: 0 },
    litecoinAdress: { type: String, unique: true, default: "No adress generated" },
    userWarnings: { type: Number, default: 0 },
    transactionHistory: { type: String, default: "No transactions" },
    lastLogin: { type: Date, default: null },
    profilePicture: String,
    createdAt: { type: Date, default: Date.now },
    verificationCode: { type: String, default: null },
    resetKey: { type: String, default: null },
    resetKeyExpiry: { type: Date, default: null }
  });
const User = mongoose.model("User", UserSchema);




const brevoClient = new SibApiV3Sdk.TransactionalEmailsApi();
brevoClient.authentications['apiKey'].apiKey = "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";


app.post("/api/auth/check-email", async (req, res) => {
  const { email } = req.body;

  if (!email) return res.status(400).json({ error: "Email is required" });

  try {
    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ error: "Email not found" });

    res.status(200).json({ message: "Email exists" });
  } catch (error) {
    console.error("Error checking email:", error);
    res.status(500).json({ error: "Server error" });
  }
});

app.post("/api/auth/forgot-password", async (req, res) => {
  const { email } = req.body;

  
  if (!email) return res.status(400).json({ error: "Email is required" });

  try {
    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ error: "Email not found" });

    const verificationCode = Math.floor(100000 + Math.random() * 900000).toString();
    user.verificationCode = verificationCode;
    await user.save();

    const sendSmtpEmail = new SibApiV3Sdk.SendSmtpEmail();
    sendSmtpEmail.subject = "Reset Your Password - Crypto Casino";
    sendSmtpEmail.sender = { name: "Crypto Casino", email: "balazs.szabo2008@gmail.com" };
    sendSmtpEmail.to = [{ email: email, name: user.username }];
    sendSmtpEmail.htmlContent = `
    <!DOCTYPE html>
    <html>
    <head>
      <title>Password Reset Code</title>
      <style>
        body {
          font-family: Arial, sans-serif; 
          background-color: #f4f4f4; 
          margin: 0; 
          padding: 0;
        }
        .container {
          background-color: #ffffff;
          border-radius: 10px; 
          overflow: hidden; 
          margin: 20px auto; 
          width: 600px; 
          box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        .header {
          background-color: #333333;
          padding: 20px;
          text-align: center;
        }
        .header img {
          max-width: 150px; 
          height: auto;
        }
        .body {
          padding: 20px;
          text-align: center;
        }
        .body h2 {
          color: #333333; 
          margin-bottom: 20px;
        }
        .body p {
          color: #555555; 
          font-size: 16px; 
          line-height: 1.5;
        }
        .code-container {
          margin: 20px auto;
          text-align: center;
          background: #007BFF;
          color: #fff;
          display: inline-block;
          padding: 10px 20px;
          border-radius: 5px;
          font-size: 24px;
          font-weight: bold;
          letter-spacing: 5px;
        }
        .footer {
          background-color: #333333; 
          padding: 10px; 
          text-align: center;
        }
        .footer p {
          color: #ffffff; 
          font-size: 12px; 
          margin: 0;
        }
        .footer a {
          color: #ffffff; 
          text-decoration: none;
        }
      </style>
    </head>
    <body>
      <table class="container" align="center" cellspacing="0" cellpadding="0">
        <!-- Header with Logo -->
        <tr>
          <td class="header">
            <img src="https://cdn.discordapp.com/attachments/1229736125392748655/1318679913502605322/Untitled1.png" alt="Crypto Casino Logo">
          </td>
        </tr>
        <!-- Body -->
        <tr>
          <td class="body">
            <h2>Password Reset Code</h2>
            <p>Hi <strong>${user.username}</strong>,<br><br>
               You requested a password reset. Use the following code to verify your request:
            </p>
            <div class="code-container">
              ${verificationCode}
            </div>
            <p>This code is valid for 15 minutes. If you didn't request this, please ignore this email.</p>
          </td>
        </tr>
        <!-- Footer -->
        <tr>
          <td class="footer">
            <p>&copy; 2024 Crypto Casino. All Rights Reserved.<br>
              <a href="https://yourdomain.com">Visit our website</a>
            </p>
          </td>
        </tr>
      </table>
    </body>
    </html>
    `;

    await brevoClient.sendTransacEmail(sendSmtpEmail);

    res.status(200).json({ message: "Verification code sent successfully" });
  } catch (error) {
    console.error("Error sending email:", error);
    res.status(500).json({ error: "Failed to send email" });
  }
});


app.post("/api/auth/verify-code", async (req, res) => {
  console.log("Request received:", req.body);

  const { code } = req.body;

  if (!code) {
    console.error("No code provided");
    return res.status(400).json({ error: "Code is required" });
  }

  try {
    // Find user by verification code
    const user = await User.findOne({ verificationCode: code });

    if (!user) {
      console.error("Invalid or expired code:", code);
      return res.status(404).json({ error: "Invalid or expired code" });
    }

    console.log("User found:", user);

    // Generate a secure reset key and a reset link
    const resetKey = `${user._id}-${Date.now()}`;
    const resetLink = `http://localhost:4002/reset-password/${encodeURIComponent(resetKey)}`;

    // Update user with reset key and expiry time
    user.resetKey = resetKey;
    user.resetKeyExpiry = Date.now() + 5 * 60 * 1000; // Valid for 5 minutes
    await user.save();

    // Send reset link via email
    const sendSmtpEmail = new SibApiV3Sdk.SendSmtpEmail();
    sendSmtpEmail.subject = "Password Reset Link - Crypto Casino";
    sendSmtpEmail.sender = { name: "Crypto Casino", email: "balazs.szabo2008@gmail.com" };
    sendSmtpEmail.to = [{ email: user.email, name: user.username }];
    sendSmtpEmail.htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Password Reset Link</title>
        <style>
          body {
            font-family: Arial, sans-serif; 
            background-color: #f4f4f4; 
            margin: 0; 
            padding: 0;
          }
          .container {
            background-color: #ffffff;
            border-radius: 10px; 
            overflow: hidden; 
            margin: 20px auto; 
            width: 600px; 
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
          }
          .header {
            background-color: #333333;
            padding: 20px;
            text-align: center;
          }
          .header img {
            max-width: 150px; 
            height: auto;
          }
          .body {
            padding: 20px;
            text-align: center;
          }
          .body h2 {
            color: #333333; 
            margin-bottom: 20px;
          }
          .body p {
            color: #555555; 
            font-size: 16px; 
            line-height: 1.5;
          }
          .button-container {
            margin: 20px auto;
            text-align: center;
          }
          .reset-button {
            display: inline-block;
            background: linear-gradient(45deg, #19ce46, #b36b00);
            color: #ffffff; 
            padding: 12px 30px; 
            border-radius: 5px; 
            text-decoration: none; 
            font-size: 18px; 
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            font-weight: bold;
            transition: background 0.3s ease;
          }
          .reset-button:hover {
            background: linear-gradient(45deg, #0056b3, #004a99);
          }
          .footer {
            background-color: #333333; 
            padding: 10px; 
            text-align: center;
          }
          .footer p {
            color: #ffffff; 
            font-size: 12px; 
            margin: 0;
          }
          .footer a {
            color: #ffffff; 
            text-decoration: none;
          }
        </style>
      </head>
      <body>
        <table class="container" align="center" cellspacing="0" cellpadding="0">
          <!-- Header with Logo -->
          <tr>
            <td class="header">
              <img src="https://cdn.discordapp.com/attachments/1229736125392748655/1318679913502605322/Untitled1.png" alt="Crypto Casino Logo">
            </td>
          </tr>
          <!-- Body -->
          <tr>
            <td class="body">
              <h2>Reset Your Password</h2>
              <p>Hi <strong>${user.username}</strong>,<br><br>
                You requested a password reset. Click the button below to reset your password:
              </p>
              <div class="button-container">
                <a href="${resetLink}" class="reset-button" style="color: black; widt="40px";">Reset Password</a>
              </div>
              <p>This link is valid for 5 minutes and is unique to your account.<br><br>
                If you didn't request this, please ignore this email.
              </p>
            </td>
          </tr>
          <!-- Footer -->
          <tr>
            <td class="footer">
              <p>&copy; 2024 Crypto Casino. All Rights Reserved.<br>
                <a href="https://yourdomain.com">Visit our website</a>
              </p>
            </td>
          </tr>
        </table>
      </body>
      </html>
      `;


    await brevoClient.sendTransacEmail(sendSmtpEmail);

    console.log("Reset link sent to email:", user.email);
    res.status(200).json({ message: "Reset link sent to your email." });
  } catch (error) {
    console.error("Error verifying code:", error);
    res.status(500).json({ error: "Server error" });
  }
});












app.get("/reset-password/:resetKey", async (req, res) => {
  const { resetKey } = req.params;

  try {
    const user = await User.findOne({ resetKey });
    if (!user || !user.resetKeyExpiry || user.resetKeyExpiry < Date.now()) {
      return res.status(404).send("Invalid or expired reset link.");
    }

    // If valid, return a fully self-contained HTML page with inline CSS and JS
    res.send(`
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - Crypto Casino</title>
    <style>
      body {
        background-color: #1E1E1E;
        margin: 0;
        height: 100vh;
        font-family: sans-serif;
      }

      #RegisterContainer {
        display: flex;
        justify-content: center;
        margin-top: 50px;
      }

      #Register {
        justify-content: center;
        align-items: center;
        background: rgba(145, 145, 145, 0.048);
        box-shadow: 0px 0px 20px 0px rgba(0, 0, 0, 0.2);
        padding: 20px;
        border-radius: 10px;
        width: 450px;
        text-align: center;
        background: linear-gradient(45deg, #2e2e2e 0%, #4e4e4e73 100%);
        animation: gradient 10s ease-in-out infinite;
        background-size: 400%;
      }

      @keyframes gradient {
        0% {
            background-position: 40% 0%;
        }
        25% {
            background-position: 45% 50%;
        }
        50% {
            background-position: 50% 100%;
        }
        75% {
            background-position: 60% 50%;
        }
        100% {
            background-position: 80% 0%;
        }
      }

      .innput {
        width: 25rem;
        height: 30px;
        border-radius: 5px;
        margin-bottom: 15px;
        border: none;
        padding: 5px;
      }

      .llaberl {
        display: flex;
        text-align: right;
        font-size: x-large;
        font-family: monospace;
        color: white;
        -webkit-animation: glow 1s ease-in-out infinite alternate;
        animation: glow 1s ease-in-out infinite alternate;
      }

      @-webkit-keyframes glow {
        from {
          text-shadow: 0 0 5px #fff, 0 0 7px #fff, 0 0 30px #424041, 0 0 40px #585858, 0 0 50px #333333, 0 0 60px #383838, 0 0 70px #494949;
        }
        to {
          text-shadow: 0 0 10px #fff, 0 1px #3a3a3a, 0 0 40px #202020, 0 0 50px #3f3f3f, 0 0 60px #2c2c2c, 0 0 70px #313131, 0 0 80px #333333;
        }
      }

      #resetPasswordSubmit {
        font-size: xx-large;
        font-family: monospace;
        color: rgb(187, 184, 184);
        width: 13rem;
        height: 40px;
        border-radius: 5px;
        background: linear-gradient(120deg, #0f0f0f, #3b3b3b, #1f0120);
        background-size: 200% 200%;
        border: none;
        cursor: pointer;
      }

      #resetPasswordSubmit:hover {
        background: linear-gradient(120deg, #616161, #6e4a12, #1f0120);
      }

      #resetPasswordSubmit:active {
        background: linear-gradient(120deg, #a10202, #5a3211, #1f0120);
      }

      #Logo {
        display: flex;
        justify-content: center;
        align-items: center;
        background-color: #1E1E1E;
        margin-top: 20px;
      }

      #lLogo {
        max-width: 20%;
        height: auto;
      }

    </style>
</head>
<body>
    <div id="Logo">
      <img src="https://cdn.discordapp.com/attachments/1229736125392748655/1318679913502605322/Untitled1.png" alt="Logo" id="lLogo" draggable="false">
    </div>

    <div id="RegisterContainer">
      <div id="Register">
        <form id="resetPasswordForm">
            <h2 style="color: white; text-align: center; font-family: monospace;">Reset Your Password</h2>
            <label for="newPasswordInput" class="llaberl">New Password</label><br>
            <input type="password" id="newPasswordInput" class="innput" placeholder="New Password" required><br><br>

            <label for="confirmPasswordInput" class="llaberl">Confirm Password</label><br>
            <input type="password" id="confirmPasswordInput" class="innput" placeholder="Confirm Password" required><br><br>

            <input type="button" id="resetPasswordSubmit" value="Reset Password">
        </form>
      </div>
    </div>

    <script>
      // On DOM load, we have the resetKey in the URL
      const urlParts = window.location.href.split("/reset-password/");
      const resetKey = urlParts[1];

      // Add event listener to the button
      document.getElementById('resetPasswordSubmit').addEventListener('click', async () => {
        const newPassword = document.getElementById("newPasswordInput").value;
        const confirmPassword = document.getElementById("confirmPasswordInput").value;

        if (!newPassword || !confirmPassword) {
            alert("Please fill in both fields.");
            return;
        }

        if (newPassword !== confirmPassword) {
            alert("Passwords do not match!");
            return;
        }

        try {
            const response = await fetch("http://localhost:4002/api/auth/reset-password", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ resetKey, newPassword }),
            });
            const result = await response.json();

            if (response.ok) {
                alert("Password reset successful! You can now login with your new password.");
                // Optionally redirect to login page
                window.location.href = "http://localhost:4002/login.html";
            } else {
                alert(result.error || "Failed to reset password.");
            }
        } catch (error) {
            console.error("Error resetting password:", error);
            alert("An unexpected error occurred. Please try again.");
        }
      });
    </script>
</body>
</html>
    `);
  } catch (error) {
    console.error("Error fetching reset page:", error);
    res.status(500).send("Server error.");
  }
});







app.post("/api/auth/reset-password", async (req, res) => {
  const { resetKey, newPassword } = req.body;

  if (!resetKey || !newPassword) {
    return res.status(400).json({ error: "Reset key and new password are required." });
  }

  try {
    const user = await User.findOne({ resetKey });
    if (!user || !user.resetKeyExpiry || user.resetKeyExpiry < Date.now()) {
      return res.status(400).json({ error: "Invalid or expired reset key." });
    }

    // Hash the new password
    const hashedPassword = await bcrypt.hash(newPassword, 10);
    user.password = hashedPassword;
    // Invalidate the reset key
    user.resetKey = null;
    user.resetKeyExpiry = null;
    user.verificationCode = null;

    await user.save();

    res.status(200).json({ message: "Password reset successfully." });
  } catch (error) {
    console.error("Error resetting password:", error);
    res.status(500).json({ error: "Server error" });
  }
});





// need to have a main wallet ! and from it user gets a wallet (like main wallet but creat (fake own wallets from it) like main wallet and server only chekcs if for user generated wallet witch is a sending adress only if crypto comes to that adress or sent to THAT adress the user who owns the wallet gets their number updated !! MAKE SURE IT CAN'T BE MANIPULATED MAKE IT SAFE !!)
    app.post("/api/auth/transactions", async (req, res) =>{
      // to do make users get their transatcion history displayed
    });

    app.post("/api/auth/GenerateBtcadress", async (req, res) =>{
      // to do make users get their transatcion history displayed
    });

    app.post("/api/auth/GenerateEthadress", async (req, res) =>{
      // to do make users get their transatcion history displayed
    });
    app.post("/api/auth/GenerateLtcadress", async (req, res) =>{
      // to do make users get their transatcion history displayed
    });

// [)------------------------------------------------------------------------------------------(]
// get Data for admin Dashboard
    app.get("/api/stats/total-users", async (req, res) => {
      try {
        const totalUsers = await User.countDocuments(); //
        res.json({ totalUsers });
      } catch (error) {
        console.error("Error fetching total users:", error);
        res.status(500).json({ error: "Server error while fetching total users" });
      }
    });

    app.get("/api/stats/online-today", async (req, res) => {
      try {
        // Set the start of the current day
        const startOfToday = new Date();
        startOfToday.setHours(0, 0, 0, 0);
    
        // counting the users who logged in since the  timer 
        const onlineToday = await User.countDocuments({ lastLogin: { $gte: startOfToday } });
    
        // returing the count with a json fromat
        res.json({ onlineToday });
      } catch (error) {
        console.error("Error fetching users online today:", error);
        res.status(500).json({ error: "Server error while fetching online users" });
      }
    });
// [)------------------------------------------------------------------------------------------(]


app.post("/api/auth/admin-login", async (req, res) => {
  const { username, password, captcha } = req.body;

  try {
      if (captcha) {
          const captchaVerification = await axios.post(
              "https://hcaptcha.com/siteverify",
              null,
              {
                  params: {
                      secret: process.env.HCAPTCHA_SECRET_KEY,
                      response: captcha,
                  },
              }
          );

          if (!captchaVerification.data.success) {
              return res.status(403).json({ isAdmin: false, message: "CAPTCHA validation failed." });
          }
      }

      const user = await User.findOne({ username });
      if (!user || user.rank !== "Admin") {
          return res.status(403).json({ isAdmin: false, message: "Access denied." });
      }

      const isPasswordMatch = await bcrypt.compare(password, user.password);
      if (!isPasswordMatch) {
          return res.status(403).json({ isAdmin: false, message: "Invalid password." });
      }

      res.json({ isAdmin: true, userId: user._id });
  } catch (error) {
      console.error("Admin login error:", error);
      res.status(500).json({ error: "Server error" });
  }
});
app.get("/api/verify-admin/:id", async (req, res) => {
  try {
      const user = await User.findById(req.params.id);
      if (!user || user.rank !== "Admin") {
          return res.status(403).json({ isAdmin: false, message: "Access denied." });
      }

      res.json({ isAdmin: true });
  } catch (error) {
      console.error("Error verifying admin:", error);
      res.status(500).json({ error: "Server error" });
  }
});





app.post("/api/auth/register", async (req, res) => {
  const { username, email, password } = req.body;
  try {
    const existingEmail = await User.findOne({ email });
    if (existingEmail) return res.status(400).json({ error: "Email already in use" });

    const existingUsername = await User.findOne({ username });
    if (existingUsername) return res.status(400).json({ error: "Username already in use" });

    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new User({ username, email, password: hashedPassword });
    await newUser.save();
    res.status(201).json({ message: "User registered successfully" });
  } catch (error) {
    console.error("Registration error:", error);
    res.status(500).json({ error: "Server error" });
  }
});

app.post("/api/auth/login", async (req, res) => {
  const { username, email, password } = req.body;
  try {
      const user = await User.findOne({ username, email });
      if (!user) return res.status(400).json({ error: "Invalid username or email" });

      const isPasswordMatch = await bcrypt.compare(password, user.password);
      if (!isPasswordMatch) return res.status(400).json({ error: "Invalid password" });

      // Update lastLogin timestamp
      user.lastLogin = new Date();
      await user.save();

      res.status(200).json({ message: "Login successful", username: user.username, userId: user._id });
  } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ error: "Server error" });
  }
});

app.get("/api/user/:id", async (req, res) => {
  try {
    const user = await User.findById(req.params.id, 'username profilePicture rank createdAt');
    if (!user) return res.status(404).json({ error: "User not found" });
    res.json({ 
      username: user.username, 
      profilePicture: user.profilePicture, 
      rank: user.rank, 
      createdAt: user.createdAt 
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Server error" });
  }
});



const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/");
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname)); 
  }
});



const upload = multer({
  storage,
  limits: { fileSize: 2 * 1024 * 1024 }, 
  fileFilter: (req, file, cb) => {
    const filetypes = /jpg|jpeg|gif|png/;
    const mimetype = filetypes.test(file.mimetype.toLowerCase());
    const extnameCheck = filetypes.test(path.extname(file.originalname).toLowerCase());

    if (mimetype && extnameCheck) {
      return cb(null, true);
    }
    cb(new Error('Invalid file type! Only JPG and PNG are allowed.'));
  }
});

// uoploadgin profiple pcute
app.post("/upload", upload.single('profilePicture'), async (req, res) => {
  try {
    const { userId } = req.body;
    if (!userId) return res.status(400).send('userId is required');

    const user = await User.findById(userId);
    if (!user) return res.status(404).send('User not found');

    // seve file palth iin mongo db
    user.profilePicture = req.file.path;
    await user.save();

    res.status(200).send('Profile picture uploaded successfully!');
  } catch (err) {
    console.error(err);
    // if i get this hsit multer rejcted and saved my ass
    res.status(500).send(err.message);
  }
});

app.use("/uploads", express.static("uploads"));


app.post("/api/auth/DisplayUserCryptoAdresses", async (req, res) => {
  try {
    const { userId, bitcoinAdress, litecoinAdress, etheriumAdress,bitcoinnumb,litecoinNumb,etheriumnumb } = req.body;

    // valide usre input
    if (!userId) return res.status(400).json({ error: "User ID is required" });

    // finding the usre
    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ error: "User not found" });

    // Update the addresses only if provided
    if (bitcoinAdress) user.bitcoinAdress = bitcoinAdress;
    if (bitcoinnumb) user.butcoinnumb = bitcoinnumb;

    if (litecoinAdress) user.litecoinAdress = litecoinAdress;
    if (litecoinNumb) user.litecoinNumb = litecoinNumb;

    if (etheriumAdress) user.etheriumAdress = etheriumAdress;
    if (etheriumAdress) user.etheriumAdress = etheriumAdress;

    // saving the updates 
    await user.save();

    // sending back the messsages
    res.status(200).json({
      message: "Crypto addresses updated successfully",
      bitcoinAdress: user.bitcoinAdress,
        bitcoinnumb: user.bitcoinnumb,
      litecoinAdress: user.litecoinAdress,
        litecoinNumb: user.litecoinNumb,
      etheriumAdress: user.etheriumAdress,
      etheriumnumb: user.etheriumnumb,

    });
  } catch (error) {
    console.error("Error updating crypto addresses:", error);
    res.status(500).json({ error: "Server error" });
  }
});



app.post("/api/security", async (req, res) =>{
  let randomnumb = Math.floor(Math.random() * (9999999999 - 1000000000) + 1000000000);
  res.json({  
    randomnumb: randomnumb
  });
});


app.post("/api/securitycode", async (req, res) =>{

  function makeid(length) {
    let result = '';
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const charactersLength = characters.length;
    let counter = 0;
    while (counter < 15) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
      counter += 1;
    }
    return result;
}

let code = makeid(4)
  res.json({  
    code: code
  });
  
});



app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
